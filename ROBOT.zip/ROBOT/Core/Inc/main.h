/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "stdio.h"
#include "ps2.h"
#include "sys.h"
#include "delay.h"
#include "driver_init.h"
#include "PID.h"
#include "SE.h"
#include "calc.h"
#include "direction_ctrl.h"
#include "misc.h"
#include "DataScope_DP.h"
#include "calc.h"
/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */
//extern uint8_t Turntble_check;
/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */
void Key_Data_Clear(void);//��������������Ч��
/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define SE_x_PWM_Pin GPIO_PIN_5
#define SE_x_PWM_GPIO_Port GPIOE
#define SE_y_PWM_Pin GPIO_PIN_6
#define SE_y_PWM_GPIO_Port GPIOE
#define Moto_turnable_EnableA_Pin GPIO_PIN_4
#define Moto_turnable_EnableA_GPIO_Port GPIOF
#define Moto_turnable_EnableB_Pin GPIO_PIN_5
#define Moto_turnable_EnableB_GPIO_Port GPIOF
#define Moto_turntable_PWM_Pin GPIO_PIN_6
#define Moto_turntable_PWM_GPIO_Port GPIOF
#define SE_front_PWM_Pin GPIO_PIN_8
#define SE_front_PWM_GPIO_Port GPIOF
#define SE_back_PWM_Pin GPIO_PIN_9
#define SE_back_PWM_GPIO_Port GPIOF
#define LED2_Pin GPIO_PIN_10
#define LED2_GPIO_Port GPIOF
#define Moto_wheel_RB_EncoderA_Pin GPIO_PIN_0
#define Moto_wheel_RB_EncoderA_GPIO_Port GPIOA
#define Moto_wheel_RB_EncoderB_Pin GPIO_PIN_1
#define Moto_wheel_RB_EncoderB_GPIO_Port GPIOA
#define Moto_wheel_turntable_EncoderA_Pin GPIO_PIN_5
#define Moto_wheel_turntable_EncoderA_GPIO_Port GPIOA
#define Moto_wheel_RT_PWM_Pin GPIO_PIN_11
#define Moto_wheel_RT_PWM_GPIO_Port GPIOE
#define Moto_Wheel_T_STBY_Pin GPIO_PIN_12
#define Moto_Wheel_T_STBY_GPIO_Port GPIOE
#define Moto_wheel_LB_PWM_Pin GPIO_PIN_13
#define Moto_wheel_LB_PWM_GPIO_Port GPIOE
#define Moto_Wheel_B_STBY_Pin GPIO_PIN_15
#define Moto_Wheel_B_STBY_GPIO_Port GPIOE
#define Moto_F_L_EnableA_Pin GPIO_PIN_12
#define Moto_F_L_EnableA_GPIO_Port GPIOB
#define Moto_F_L_EnableB_Pin GPIO_PIN_13
#define Moto_F_L_EnableB_GPIO_Port GPIOB
#define Moto_F_L_PWM_Pin GPIO_PIN_14
#define Moto_F_L_PWM_GPIO_Port GPIOB
#define Moto_F_R_PWM_Pin GPIO_PIN_15
#define Moto_F_R_PWM_GPIO_Port GPIOB
#define Moto_F_R_EnableA_Pin GPIO_PIN_10
#define Moto_F_R_EnableA_GPIO_Port GPIOD
#define Moto_F_R_EnableB_Pin GPIO_PIN_11
#define Moto_F_R_EnableB_GPIO_Port GPIOD
#define Moto_wheel_LB_EncoderA_Pin GPIO_PIN_12
#define Moto_wheel_LB_EncoderA_GPIO_Port GPIOD
#define Moto_wheel_LB_EncoderB_Pin GPIO_PIN_13
#define Moto_wheel_LB_EncoderB_GPIO_Port GPIOD
#define Moto_wheel_LB_EnableA_Pin GPIO_PIN_14
#define Moto_wheel_LB_EnableA_GPIO_Port GPIOD
#define Moto_wheel_LB_EnableB_Pin GPIO_PIN_15
#define Moto_wheel_LB_EnableB_GPIO_Port GPIOD
#define Moto_wheel_LT_EncoderA_Pin GPIO_PIN_6
#define Moto_wheel_LT_EncoderA_GPIO_Port GPIOC
#define Moto_wheel_LT_EncoderB_Pin GPIO_PIN_7
#define Moto_wheel_LT_EncoderB_GPIO_Port GPIOC
#define Moto_wheel_LT_PWM_Pin GPIO_PIN_8
#define Moto_wheel_LT_PWM_GPIO_Port GPIOA
#define Moto_wheel_RB_PWM_Pin GPIO_PIN_11
#define Moto_wheel_RB_PWM_GPIO_Port GPIOA
#define ps2_DI_Pin GPIO_PIN_0
#define ps2_DI_GPIO_Port GPIOD
#define ps2_DO_Pin GPIO_PIN_1
#define ps2_DO_GPIO_Port GPIOD
#define ps2_cs_Pin GPIO_PIN_2
#define ps2_cs_GPIO_Port GPIOD
#define ps2_clk_Pin GPIO_PIN_3
#define ps2_clk_GPIO_Port GPIOD
#define Moto_wheel_RB_EnableA_Pin GPIO_PIN_6
#define Moto_wheel_RB_EnableA_GPIO_Port GPIOD
#define Moto_wheel_RB_EnableB_Pin GPIO_PIN_7
#define Moto_wheel_RB_EnableB_GPIO_Port GPIOD
#define Moto_wheel_LT_EnableA_Pin GPIO_PIN_9
#define Moto_wheel_LT_EnableA_GPIO_Port GPIOG
#define Moto_wheel_LT_EnableB_Pin GPIO_PIN_10
#define Moto_wheel_LT_EnableB_GPIO_Port GPIOG
#define Moto_wheel_turntable_EncoderB_Pin GPIO_PIN_3
#define Moto_wheel_turntable_EncoderB_GPIO_Port GPIOB
#define Moto_wheel_RT_EncoderA_Pin GPIO_PIN_4
#define Moto_wheel_RT_EncoderA_GPIO_Port GPIOB
#define Moto_wheel_RT_EncoderB_Pin GPIO_PIN_5
#define Moto_wheel_RT_EncoderB_GPIO_Port GPIOB
#define Moto_wheel_RT_EnableA_Pin GPIO_PIN_6
#define Moto_wheel_RT_EnableA_GPIO_Port GPIOB
#define Moto_wheel_RT_EnableB_Pin GPIO_PIN_7
#define Moto_wheel_RT_EnableB_GPIO_Port GPIOB
/* USER CODE BEGIN Private defines */
//#define huart_nonPC huart3
//#define UART_nonPC USART3
#define huart_nonPC huart3
#define UART_nonPC USART3
#define huart_PC huart1
#define UART_PC USART1
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
