/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    gpio.h
  * @brief   This file contains all the function prototypes for
  *          the gpio.c file
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2022 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __GPIO_H__
#define __GPIO_H__

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* USER CODE BEGIN Private defines */
#define LED1 PFout(9)
#define LED2 PFout(10)
//#define ELCF2 PCout(1)
//#define ELCB1 PCout(0)
//#define ELCB2 PCout(2)
#define Wheel_LT_EnableA PGout(9)
#define Wheel_LT_EnableB PGout(10)
#define Wheel_RT_EnableA PBout(6)
#define Wheel_RT_EnableB PBout(7)
#define Wheel_LB_EnableA PDout(14)
#define Wheel_LB_EnableB PDout(15)
#define Wheel_RB_EnableA PDout(6)
#define Wheel_RB_EnableB PDout(7)
#define Turnable_EnableA PFout(4)
#define Turnable_EnableB PFout(5)
#define Moto_F_R_EnableA PDout(10)
#define Moto_F_R_EnableB PDout(11)
#define Moto_F_L_EnableA PBout(12)
#define Moto_F_L_EnableB PBout(13)
#define Moto_Wheel_T_STBY PEout(12)
#define Moto_Wheel_B_STBY PEout(15)
/* USER CODE END Private defines */

void MX_GPIO_Init(void);

/* USER CODE BEGIN Prototypes */

/* USER CODE END Prototypes */

#ifdef __cplusplus
}
#endif
#endif /*__ GPIO_H__ */

